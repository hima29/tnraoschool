<div class="cbp-row">
	<div class="one whole">
		<div class="course-lesson-count">			
			<i class="icon-skilledtime4"></i>
        	<?php echo esc_html( $lesson_count ) . '&nbsp;' .  __( 'Lessons', 'superwise-plugin' ); ?>
		</div>
        <div class="course-lesson-count author">
        <i class="icon-skilledround-account-button-with-user-inside2"></i>
        	<?php echo get_the_author(); ?>
        </div>
	</div>
</div>