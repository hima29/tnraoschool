<h1><?php echo esc_html( $course->getName() ); ?></h1>

