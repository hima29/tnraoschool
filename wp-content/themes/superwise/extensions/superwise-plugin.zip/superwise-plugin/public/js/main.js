jQuery(function ($) {

    "use strict";


});